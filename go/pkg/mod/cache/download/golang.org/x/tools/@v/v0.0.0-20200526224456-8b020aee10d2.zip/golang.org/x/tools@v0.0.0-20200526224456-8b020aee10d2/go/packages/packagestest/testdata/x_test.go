package fake1_test

type AnXTestType string //@check("AnXTestType","AnXTestType")
